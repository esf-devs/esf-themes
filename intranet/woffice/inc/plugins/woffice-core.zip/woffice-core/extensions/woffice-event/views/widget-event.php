<?php if ( ! defined( 'ABSPATH' ) ) die( 'Direct access forbidden.' );

if (is_user_logged_in()) {
	echo $before_widget;
	echo $title;
	global $bp;
	$user_id = $bp->displayed_user->id;
	echo do_shortcode('[woffice_calendar visibility="personal" id="' . $user_id . '"]');
	echo $after_widget;
}