<?php if (!defined('FW')) {
    die('Forbidden');
}

$days = [
    'monday'    => __('Monday', 'woffice'),
    'tuesday'   => __('Tuesday', 'woffice'),
    'wednesday' => __('Wednesday', 'woffice'),
    'thursday'  => __('Thursday', 'woffice'),
    'friday'    => __('Friday', 'woffice'),
    'saturday'  => __('Saturday', 'woffice'),
    'sunday'    => __('Sunday', 'woffice')
];

$options = array(
    'build' => array(
        'type'    => 'box',
        'title'   => __('Calender', 'woffice'),
        'options' => array(
            'woffice_calender_days'         => array(
                'type'    => 'multi-select',
                'label'   => __('Days', 'woffice'),
                'desc'    => __('Select the days that\'ll show up in the calendar.', 'woffice'),
                'choices' => $days,
                'value'  => array_keys($days)
            ),
            'woffice_calender_starting_day' => array(
                'type'    => 'select',
                'label'   => __('Starting day', 'woffice'),
                'desc'    => __('Select starting day', 'woffice'),
                'choices' => $days,
                'value'   => 'monday'
            ),
        )
    ),
);
