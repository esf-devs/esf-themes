<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Alert Box', 'woffice' ),
		'description' => __( 'This is a box that you can customize with an icon and a background', 'woffice'),
		'tab'         => __( 'Content Elements', 'woffice' ),
		'icon' 		  => 'fa fa-exclamation-triangle',
	)
);